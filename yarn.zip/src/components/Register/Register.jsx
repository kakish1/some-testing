const Register = () => {
  return <>register</>;
};

export default Register;
